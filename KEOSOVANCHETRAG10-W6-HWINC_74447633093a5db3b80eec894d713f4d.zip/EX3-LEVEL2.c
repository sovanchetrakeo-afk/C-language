#include <stdio>
int main() {
    int the score;
    printf(" Put the score ");
    scanf("%d" ,&the score);
    if ( the score >=90 && the score <=100 );
    char letter = 'A' ;
    printf ("The grade is   ", letter );
    if ( the score >=80 && the score <=89 );
    char letter = 'B' ;
    printf ("The grade is   ", letter );
    if ( the score >=70 && the score <= 79 );
    char letter ='C' ;
    printf ("The grade is  " ,letter);
    if (the score <70 );
    char letter = 'F' ;
    printf (" The grade is  ", letter)

    return 0;

}    
